import tempfile, os
os.environ['DATA_DIR']=tempfile.mkdtemp(prefix='ung-test-')
from fastapi.testclient import TestClient
from main import app, db, password_hash

def test_complete_flow():
    with TestClient(app) as client:
        with db() as c: c.execute('INSERT INTO users(nickname,name,password,role) VALUES(?,?,?,?)',('owner','Owner',password_hash('Test-password-123'),'admin'))
        assert client.get('/dashboard').status_code==401
        assert client.post('/auth/login',json={'nickname':'owner','password':'wrong'}).status_code==401
        data=client.post('/auth/login',json={'nickname':'owner','password':'Test-password-123'}).json()
        token=data['token']; headers={'Authorization':'Bearer '+token}
        assert client.get('/dashboard',headers=headers).json()['latest'] is None
        assert client.post('/admin/users',headers=headers,json={'nickname':'reader','name':'Reader','password':'reader-password','role':'viewer'}).status_code==200
        reader=client.post('/auth/login',json={'nickname':'reader','password':'reader-password'}).json()['token']
        rh={'Authorization':'Bearer '+reader}
        metric={'period':'2026-10','revenue':100,'expenses':70,'profit':20,'gas':2,'oil':1,'investment':10}
        assert client.put('/metrics',headers=rh,json=metric).status_code==403
        with client.websocket_connect('/ws') as ws:
            ws.send_json({'token':reader})
            assert ws.receive_json()['type']=='connected'
            assert client.put('/metrics',headers=headers,json=metric).status_code==200
            assert ws.receive_json()['type']=='changed'
            assert client.get('/dashboard',headers=rh).json()['latest']['revenue']==100
            ws.close()
        bad={**metric,'period':'2026-13'}
        assert client.put('/metrics',headers=headers,json=bad).status_code==422
        assert client.post('/reports',headers=rh,files={'file':('r.csv',b'a,b\n1,2')}).status_code==403
        assert client.post('/reports',headers=headers,files={'file':('x.exe',b'bad')}).status_code==400
        report=client.post('/reports',headers=headers,files={'file':('test.csv',b'a,b\n1,2')}).json()
        rid=report['id']
        assert client.get(f'/reports/{rid}/download').status_code==401
        assert client.get(f'/reports/{rid}/download',headers=rh).content==b'a,b\n1,2'
        uid=next(u['id'] for u in client.get('/admin/users',headers=headers).json() if u['nickname']=='reader')
        assert client.patch(f'/admin/users/{uid}',headers=headers,json={'active':False}).status_code==200
        assert client.get('/dashboard',headers=rh).status_code==401
        assert client.delete('/reports/'+rid,headers=headers).status_code==200
        assert client.get(f'/reports/{rid}/download',headers=headers).status_code==404
        assert client.post('/auth/logout',headers=headers).status_code==200
        assert client.get('/me',headers=headers).status_code==401
    with TestClient(app) as restarted:
        d=restarted.post('/auth/login',json={'nickname':'owner','password':'Test-password-123'}).json()
        h={'Authorization':'Bearer '+d['token']}
        assert restarted.get('/dashboard',headers=h).json()['latest']['revenue']==100
        assert restarted.post('/me/password',headers=h,json={'old_password':'Test-password-123','new_password':'new-password-123'}).status_code==200
        assert restarted.get('/me',headers=h).status_code==401
        assert restarted.post('/auth/login',json={'nickname':'owner','password':'new-password-123'}).status_code==200

def test_login_throttle():
    with TestClient(app) as c:
        for _ in range(10): assert c.post('/auth/login',json={'nickname':'nobody','password':'bad'}).status_code==401
        assert c.post('/auth/login',json={'nickname':'nobody','password':'bad'}).status_code==429
