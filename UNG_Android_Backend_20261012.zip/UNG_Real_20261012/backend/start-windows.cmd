@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3.11 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m uvicorn main:app --host 0.0.0.0 --port 8000
pause
exit /b
:fail
echo Python 3.11 o'rnatilganini tekshiring.
pause
