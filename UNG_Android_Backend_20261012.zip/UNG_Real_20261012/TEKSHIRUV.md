# Tekshiruv natijalari — 2026-10-12

- Backend: pytest — 2 ta integratsion test o‘tdi; login, ruxsatlar, WebSocket o‘zgarish xabari, fayl yuklash/yuklab olish, bloklash, sessiyani bekor qilish, parol yangilash va qayta ishga tushishda saqlanish tekshirildi.
- TypeScript: tsc --noEmit — xatosiz.
- Expo SDK paketlari: expo install --check — mos.
- Android JavaScript/Hermes bundle: expo export --platform android — muvaffaqiyatli, 1135 modul.

Native APK/Gradle build bajarilmagan: Android SDK va Expo akkauntiga kirish bu muhitda mavjud emas.
Haqiqiy Android qurilmada sinov va tashqi HTTPS serverga deploy hali bajarilmagan.
Baza va testlarda ishlatilgan foydalanuvchilar ZIPga kiritilmagan.
