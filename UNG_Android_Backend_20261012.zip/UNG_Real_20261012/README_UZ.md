# O‘zbekneftgaz Analitika — Android va backend

Bu ZIP ichida APK emas, APK yig‘ishga tayyor mobil loyiha va ishlaydigan backend kodi mavjud.
Server hali internetga joylanmagan. EAS akkaunti va doimiy HTTPS server kerak.

## Nimalar ishlaydi
- Server orqali login, 7 kunlik sessiya, telefonda SecureStore orqali token saqlash.
- Administrator, xodim va faqat ko‘ruvchi rollari. Admin foydalanuvchi yaratadi/bloklaydi.
- Administrator oylik ko‘rsatkichlarni kiritadi/tahrirlaydi. Demo raqamlar yo‘q.
- WebSocket o‘zgarish xabaridan keyin ekran ma’lumotni qayta oladi; qo‘shimcha har 15 soniyada yangilanadi.
- Internet uzilganda ogohlantirish va ulanish tiklanganda qayta yuklash.
- PDF, XLS, XLSX, CSV fayllarini serverga yuklash, qidirish, yuklab olish/ulashish; administrator o‘chira oladi.
- Profil ismi va parol o‘zgartirish. Parol o‘zgarganda avvalgi sessiyalar bekor qilinadi.
- Audit tarixi. SQLite bazasi va hisobotlar Docker doimiy volume ichida qoladi.
- Prognoz oxirgi ikki davrning daromad o‘sishidan hisoblanadi. Bu AI yoki rasmiy prognoz emas.

Korxonaning ichki axborot tizimiga avtomatik ulanish yo‘q: buning uchun uning API manzili va ruxsati kerak.
Excel/PDF fayllari saqlanadi, ularning ichidagi jadvallar avtomatik ko‘rsatkichka aylantirilmaydi.
Asl prototipdagi ishlamaydigan AI va til almashtirish tugmalari chiqarib tashlangan.
Real vaqt yangilanishi ilova ochiq va internetga ulanganida ishlaydi; fon push bildirishnomalari kiritilmagan.

## 1. Serverni internetda ishga tushirish (Docker o‘rnatilgan Linux VPS)

Domen/subdomenning A yozuvini VPS IP manziliga yo‘naltiring. Serverda 80 va 443 portlarini oching.
Loyiha papkasiga kiring, `.env.example` faylidan `.env` nusxasini yarating va o‘zingizning domenni yozing:

```sh
cp .env.example .env
nano .env
```

Masalan, API_DOMAIN qiymati siz egalik qiladigan `api.sizning-domen.uz` bo‘ladi.
So‘ng:

```sh
docker compose up -d --build
docker compose exec api python admin.py
```

Admin login, ism va parolni o‘zingiz kiriting. Standart ochiq parol yo‘q.
Brauzerda `https://SIZNING_DOMEN/health` ni oching: `{"status":"ok"}` chiqishi kerak.
Caddy sertifikatni domen va DNS to‘g‘ri bo‘lsa avtomatik oladi.

Diagnostika:
```sh
docker compose logs --tail=100 api proxy
```

Baza va fayllar `ung-data` nomli Compose volume ichida. `docker compose down -v` ma’lumotlarni o‘chiradi — ishlatmang.
Zaxira uchun:
```sh
mkdir -p backups
docker compose stop api
docker compose cp api:/data ./backups/data
docker compose start api
```
Har backupni alohida sana papkasiga nusxalang. Qayta tiklashda API ni to‘xtating va butun data papkasini qaytaring.
Bir API worker bilan ishlating: WebSocket ulanishlari shu jarayonda saqlanadi.

## 2. Windowsda APK chiqarish

1. Node.js 22 LTS o‘rnating. ZIPni qisqa yo‘lga oching, masalan `C:\UNG`.
2. `mobile` papkasidagi `build-apk.cmd` ni ikki marta bosing.
3. Expo akkauntingizga kiring (parolni chatga yubormang).
4. EAS yangi loyiha yaratishni so‘rasa tasdiqlang.
5. Android keystore yaratishni so‘rasa yangi loyiha uchun `Yes` tanlang. Oldindan tarqatilgan ilovani yangilayotgan bo‘lsangiz, uning avvalgi kaliti kerak.
6. Build tugaganda terminaldagi havoladan `.apk` faylni yuklab oling.
7. Telefoningizga o‘tkazing, faylni ochib Android so‘ragan o‘rnatish ruxsatini bering va o‘rnating.

PowerShellda qo‘lda:
```powershell
cd C:\UNG\mobile
npm.cmd ci
npx.cmd expo install --check
npx.cmd eas-cli login
npx.cmd eas-cli init
npx.cmd eas-cli build -p android --profile preview
```

`preview` profili APK chiqaradi. `production` Play Store uchun AAB chiqaradi.
APK ichida JS jamlanadi: ishlashi uchun kompyuterda Metro yoki Expo Go ochiq turishi kerak emas.
EAS akkaunti, navbat/kvota va build xizmatining amaldagi shartlari Expo tomonidan boshqariladi.

## 3. Telefonda kirish

Ilovani oching. Server manzili maydoniga `https://SIZNING_DOMEN` ni kiriting (oxiriga /docs yozmang).
Serverda yaratgan admin login va paroli bilan kiring.
Profil → Admin panel → Ko‘rsatkich kiritish orqali haqiqiy ma’lumotlarni yozing.
Daromad, foyda, xarajat, investitsiya — mlrd so‘m; gaz — mlrd m³; neft — mln tonna.
Boshqa telefonlarda ham shu server manzilini kiriting. Foydalanuvchilarni admin paneldan yarating.

## 4. Faqat kompyuterda backendni sinash

`backend/start-windows.cmd` ni ishga tushiring. Python 3.11 kerak.
Keyin alohida oynada `backend/create-admin.cmd` ni oching.
Kompyuterda `http://127.0.0.1:8000/docs` orqali API ni ko‘rish mumkin.
APK xavfsiz HTTPS manzil qabul qiladi. Telefon uchun yuqoridagi internet serverini ishlating.

## Tekshiruv

Backend testlari:
```sh
pip install -r requirements.txt
pip install pytest httpx
pytest -q
```
Mobil kod:
```sh
npm ci
npm run check
npx expo install --check
npx expo export --platform android
```

Manbalar: https://docs.expo.dev/build-reference/apk/ va https://docs.expo.dev/build/setup/
