import * as SecureStore from 'expo-secure-store';
export type User={id:number;nickname:string;name:string;role:'admin'|'employee'|'viewer';active:number};
export type Metric={period:string;revenue:number;expenses:number;profit:number;gas:number;oil:number;investment:number;updated_at:number};
export type Report={id:string;name:string;size:number;created_at:number};
export const DEFAULT_URL=process.env.EXPO_PUBLIC_API_URL||'';
export async function request(base:string,token:string,path:string,method='GET',body?:unknown):Promise<any>{
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),30000);
 try {
  const response=await fetch(base+path,{method,signal:controller.signal,headers:{...(token?{Authorization:`Bearer ${token}`} :{}),...(body && !(body instanceof FormData)?{'Content-Type':'application/json'}:{})},body:body instanceof FormData?body:body?JSON.stringify(body):undefined});
  if(!response.ok){let data:any={};try{data=await response.json()}catch{}const e:any=new Error(typeof data.detail==='string'?data.detail:`So‘rov bajarilmadi (${response.status})`);e.status=response.status;throw e;}
  return await response.json();
 }catch(e:any){if(e.name==='AbortError')throw new Error('Server javob bermadi. Internet va server manzilini tekshiring.');throw e}finally{clearTimeout(timer)}
}
export const vault={get:SecureStore.getItemAsync,set:SecureStore.setItemAsync,remove:SecureStore.deleteItemAsync};
