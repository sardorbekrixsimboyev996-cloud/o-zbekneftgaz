@echo off
cd /d "%~dp0"
call npm ci
if errorlevel 1 goto fail
call npx expo install --check
if errorlevel 1 goto fail
call npx eas-cli login
if errorlevel 1 goto fail
call npx eas-cli init
if errorlevel 1 goto fail
call npx eas-cli build -p android --profile preview
if errorlevel 1 goto fail
pause
exit /b 0
:fail
echo Xatolik yuz berdi. Yuqoridagi xabarni yuboring.
pause
exit /b 1
