# Android ilova
To‘liq yo‘riqnoma: yuqoridagi README_UZ.md.
Windows uchun build-apk.cmd ni oching.
Loginlar serverda yaratiladi; demo login mavjud emas.
